#  ZXingCpp Demo Project

This demo-project sets up a basic `AVCaptureSession` and uses ZXing on the incoming frames.
